
package goaltest;

public class Goal {

    public Goal(){

        
        GoalTest.root.getChildren().addAll();
        interactions();
    }
    
    private void interactions(){
        //Exercise 4   
        
    }
}
