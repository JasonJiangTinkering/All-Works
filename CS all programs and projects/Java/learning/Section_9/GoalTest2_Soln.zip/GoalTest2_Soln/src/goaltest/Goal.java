
package goaltest;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Goal {
    private Image dukeImage;
    private ImageView dukeImageView;
    private Image gloveImage;
    private ImageView gloveImageView;

    public Goal(double x, double y){
        dukeImage = new Image(getClass().getResource("Images/Duke.png").toString());
        dukeImageView = new ImageView(dukeImage);
        gloveImage = new Image(getClass().getResource("Images/Glove.png").toString());
        gloveImageView = new ImageView(gloveImage);
        
        gloveImageView.setPreserveRatio(true);
        gloveImageView.setFitWidth(38);
        
        dukeImageView.setX(x);
        dukeImageView.setY(y);
        gloveImageView.setX(x +13);
        gloveImageView.setY(y -10);
        
        GoalTest.root.getChildren().addAll(dukeImageView, gloveImageView);
        interactions();
    }
    
    private void interactions(){
        //Exercise 4   
        
    }
}
