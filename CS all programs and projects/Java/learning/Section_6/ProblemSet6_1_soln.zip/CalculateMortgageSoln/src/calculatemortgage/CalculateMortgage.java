package calculatemortgage;

public class CalculateMortgage {
    
    /**
     * Display monthly balance for the term of a loan
     *
     * @param loanAmount total amount of loan
     * @param termInYears term of loan in years
     * @param interestRate loan interest rate, 5.6% = 5.6
     * @param monthlyPayment monthly payment
     */
    public static void displayMonthlyBalance(int loanAmount,
            int termInYears, double interestRate, double monthlyPayment) {

        interestRate /= 100.0;
        double monthlyRate = interestRate / 12.0;
        int termInMonths = termInYears * 12;

      // Loop through the term of the loan tracking the balance
        double balance = loanAmount;
        for (int i = 0; i < termInMonths; i++) {

         // Add interest to the balance
            balance += (balance * monthlyRate);

         // Subtract the monthly payment
            balance -= monthlyPayment;

         // Display running balance
            System.out.println("Balance after payment " + (i + 1) + ": " + balance);
        }
    }

}
