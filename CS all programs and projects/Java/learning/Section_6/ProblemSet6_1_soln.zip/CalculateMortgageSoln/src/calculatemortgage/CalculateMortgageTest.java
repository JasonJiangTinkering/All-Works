package calculatemortgage;

import java.util.Scanner;

public class CalculateMortgageTest {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

      // Prompt user for details of loan
        System.out.print("Enter loan amount: ");
        int loanAmount = scanner.nextInt();
        System.out.print("Enter loan term (in years): ");
        int termInYears = scanner.nextInt();
        System.out.print("Enter interest rate: ");
        double interestRate = scanner.nextDouble();
        System.out.print("Enter monthlyPayment amount: ");
        double monthlyPayment = scanner.nextDouble();

      // Calculate the monthly payment
      // Display details of the loan
        System.out.println("Loan Amount: " + loanAmount);
        System.out.println("Loan Term: " + termInYears + " years");
        System.out.println("Interest Rate: " + interestRate);
        System.out.println("Monthly Payment: " + monthlyPayment);

      // Now display the monthly balance for
        // the term of the loan
        CalculateMortgage.displayMonthlyBalance(
                loanAmount, termInYears, interestRate, monthlyPayment);
    }

}
