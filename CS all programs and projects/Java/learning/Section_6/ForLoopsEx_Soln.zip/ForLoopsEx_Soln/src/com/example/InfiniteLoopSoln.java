
package com.example;


public class InfiniteLoopSoln {
   public static void main(String[] args) {
   
    
     
     // Below given for loop will run infinite times.
     
     for(int i=0;i<5;i++)
       System.out.println("Hello");
     
     
      // To terminate this program press ctrl + c in the console.
      
  }
} 
    

