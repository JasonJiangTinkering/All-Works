
package com.example;

public class UsingBreak {

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            if (i == 4) {
                break;
            }
            System.out.println(i + "\t");

        }

    }
}


