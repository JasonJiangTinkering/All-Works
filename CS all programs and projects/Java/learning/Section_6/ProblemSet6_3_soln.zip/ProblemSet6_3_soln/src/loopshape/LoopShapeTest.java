
package loopshape;

public class LoopShapeTest {
    public static void main(String[] args) {
        
        LoopShape.createRectangle(5, 4);
        LoopShape.createTriangle(5);
    }   
}
