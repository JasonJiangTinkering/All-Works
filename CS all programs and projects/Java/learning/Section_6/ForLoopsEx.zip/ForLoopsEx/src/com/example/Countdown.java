
package com.example;

public class Countdown {

    public static void main(String[] args) {
        
        System.out.println("Countdown to Launch: ");

        for(int i = 5; i >= 0; i--) {
            System.out.print(i +" "); 
        }

        System.out.println("Blast Off!");
    }
}
