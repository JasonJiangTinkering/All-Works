
package com.example;


   public class VariableScopeDemo {

    public static void main(String args[]){
       
        for (int i = 0; i < 9;  i++ ){
            System.out.println("i: " + i);
         }
        // uncomment the following line to see the error message
          // System.out.println("i: " + i);
    }        
 }
 
    

