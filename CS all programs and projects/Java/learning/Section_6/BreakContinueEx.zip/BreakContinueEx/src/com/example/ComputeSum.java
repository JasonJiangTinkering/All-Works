package com.example;

import java.util.Scanner;

public class ComputeSum {

    public static void main(String[] args) {

       

    }
}
