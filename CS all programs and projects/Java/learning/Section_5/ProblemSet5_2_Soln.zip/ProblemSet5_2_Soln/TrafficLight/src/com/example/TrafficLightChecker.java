/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import java.util.Scanner;

public class TrafficLightChecker {

    public static void main(String args[]) {

        String nextColor;

        Scanner in = new Scanner(System.in);
        System.out.println("Enter the current color");
        String currentColor = in.next();
        if (currentColor.equals("red")) {
            nextColor = "green";
            System.out.println("Next Traffic Light is " + nextColor);
        } else if (currentColor.equals("green")) {
            nextColor = "yellow";
            System.out.println("Next Traffic Light is " + nextColor);
        } else if (currentColor.equals("yellow")) {
            nextColor = "red";
            System.out.println("Next Traffic Light is " + nextColor);
        } else {

            System.out.println("Invalid color");
        }
    }

}
