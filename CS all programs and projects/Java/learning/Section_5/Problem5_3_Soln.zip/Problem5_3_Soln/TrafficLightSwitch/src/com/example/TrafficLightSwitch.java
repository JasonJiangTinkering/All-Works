package com.example;

import java.util.Scanner;

public class TrafficLightSwitch {

    public static void main(String args[]) {

        String nextColor;

      
        System.out.println("Enter the current color");
          Scanner in = new Scanner(System.in);
        String currentColor = in.next();
        switch (currentColor) {
            case "red":
                nextColor = "green";
                System.out.println("Next Traffic Light is " + nextColor);
                break;
            case "green":
                nextColor = "yellow";
                System.out.println("Next Traffic Light is " + nextColor);
                break;
            case "yellow":
                nextColor = "red";
                System.out.println("Next Traffic Light is " + nextColor);
                break;
            default:
                System.out.println("Invalid Color");
                break;
        }
    }

}
