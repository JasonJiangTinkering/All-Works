
package com.example;

public class StopLightSwitch {

    public static void main(String args[]) {

        String   nextColor;
        int  currentColor = 4;
        switch (currentColor) {
            case 1:
                nextColor = "green";
                System.out.println("Next Traffic Light is " + nextColor);
                break;
            case 2:
                nextColor = "yellow";
                System.out.println("Next Traffic Light is " + nextColor);
                break;
            case 3:
                nextColor = "red";
                System.out.println("Next Traffic Light is " + nextColor);
                break;
            default:
                nextColor = "red";
                System.out.println("Invalid Color");
                break;
        }
    }

}
