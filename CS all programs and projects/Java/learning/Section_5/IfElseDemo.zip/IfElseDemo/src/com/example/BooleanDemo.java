/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;


public class BooleanDemo {

    public static void main(String args[]) {

        boolean passed, largeVenue, grade;

        passed = true;  // Assigning Value
        largeVenue = false; // Assigning Value
        grade = passed;    // Assigning Variable

        System.out.println(passed); // Printing Value
        System.out.println(largeVenue); // Printing Value
        System.out.println(grade); // Printing Value

    }

}
