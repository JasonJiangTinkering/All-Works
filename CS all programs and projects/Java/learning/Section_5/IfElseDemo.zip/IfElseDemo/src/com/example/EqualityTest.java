/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */
public class EqualityTest {

    public static void main(String args[]) {
        int value1 = 15;
        int value2 = 24;
        boolean res1 = value1 == 15;
        System.out.println("res1:" + res1);
        boolean res2 = value1 == value2;
        System.out.println("res2: " + res2);
    }

}

