/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

public class BooleanDriving {

    public static void main(String args[]) {
        String left = "museum";
        String straight = "gym";
        String right = "restaurant";
        boolean isLeft = false;
        boolean isStraight = true;
        boolean isRight = false;

        System.out.print("Go straight ahead");
    }

}
