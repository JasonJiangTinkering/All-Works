package com.example;

public class IfDemo {

    public static void main(String args[]) {

        boolean drivingUnderAge;

        int age = 16;

//        if (age <= 18) {
//            drivingUnderAge = true;
//            System.out.println("Was Driving Under Age: " + drivingUnderAge);
//        }
      
 drivingUnderAge= (age <=18);
 System.out.println("Was Driving Under Age: " + drivingUnderAge);
    }
}
