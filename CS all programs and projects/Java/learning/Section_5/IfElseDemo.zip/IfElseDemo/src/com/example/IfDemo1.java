/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

public class IfDemo1 {
    
    
public static void main(String args[]) {
        int grade = 85;
        if (grade > 88) {
            System.out.println("You made the Honor Roll.");
        }
        
         if (grade <=88) {
            System.out.println("You are eligible for tutoring.");
        }

    }
}
