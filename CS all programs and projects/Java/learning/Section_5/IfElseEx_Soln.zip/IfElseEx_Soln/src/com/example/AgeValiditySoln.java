/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import java.util.Scanner;

/**
 *
 * @author anshenoy
 */
public class AgeValiditySoln {

    public static void main(String[] args) {

        System.out.println("Enter age");
        Scanner keyboard = new Scanner(System.in);
        int age = keyboard.nextInt();

        boolean drivingUnderAge = false;
        drivingUnderAge = age <= 18;

        System.out.println("Driving Under Age? " + drivingUnderAge);
    }
}
