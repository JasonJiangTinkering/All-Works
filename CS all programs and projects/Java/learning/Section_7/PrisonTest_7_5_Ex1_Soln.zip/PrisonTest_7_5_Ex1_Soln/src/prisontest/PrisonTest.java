package prisontest;

public class PrisonTest {
    public static void main(String[] args){
        Cell cellA1 = new Cell("A1",false);
        Prisoner bubba = new Prisoner("Bubba", 2.08, 4, cellA1);
        
        bubba.display();
        bubba.openDoor();
        bubba.openDoor();
        bubba.openDoor();
    }
}
