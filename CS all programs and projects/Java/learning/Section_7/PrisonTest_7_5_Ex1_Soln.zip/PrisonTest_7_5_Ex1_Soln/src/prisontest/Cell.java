
package prisontest;

public class Cell {
    public String name;
    public boolean isOpen;
    
    public Cell(String name, boolean isOpen){
        this.name = name;
        this.isOpen = isOpen;
    }
}
