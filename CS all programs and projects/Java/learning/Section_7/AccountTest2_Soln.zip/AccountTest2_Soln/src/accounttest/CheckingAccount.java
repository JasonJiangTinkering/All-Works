package accounttest;

public class CheckingAccount {
    public double balance;
    public String name;
}
