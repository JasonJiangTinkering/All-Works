package accounttest;

public class AccountTest {
    public static void main(String[] args) {
        CheckingAccount ca0001 = new CheckingAccount();
        ca0001.balance = 1000;
        ca0001.name = "Damien";
    }
}
