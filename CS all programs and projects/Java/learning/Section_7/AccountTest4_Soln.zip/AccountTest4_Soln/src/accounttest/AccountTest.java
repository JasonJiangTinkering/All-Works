package accounttest;

public class AccountTest {
    public static void main(String[] args) {
        CheckingAccount ca1 = new CheckingAccount();
        ca1.balance = 1000;
        ca1.name = "Damien";
        
        //ca1.withdraw(2000);
        //ca1.withdraw(-100);
        //ca1.withdraw(50);
        
        Bond cd1 = new Bond();
        cd1.balance=1000;
        int term = 12;
        cd1.setTermAndRate(term);
        for(int i=0; i<=term; i++)
            cd1.earnInterest();
    }
}
