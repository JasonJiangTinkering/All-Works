package prisontest;

public class PrisonTest {
    public static void main(String[] args) {

        Prisoner bubba = new Prisoner();
        Prisoner twitch = new Prisoner();
        
        bubba.name = new String("Bubba");
        twitch.name = new String("Bubba");
        System.out.println(bubba.name == twitch.name);
        
        bubba.name = "Bubba";
        twitch.name = "Bubba";
        System.out.println(bubba.name == twitch.name);
    } 
}
