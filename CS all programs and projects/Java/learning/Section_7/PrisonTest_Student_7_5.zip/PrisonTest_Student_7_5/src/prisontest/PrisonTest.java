package prisontest;

public class PrisonTest {
    public static void main(String[] args){
        
        Prisoner bubba = new Prisoner("Bubba", 2.08, 4);
    }
}
