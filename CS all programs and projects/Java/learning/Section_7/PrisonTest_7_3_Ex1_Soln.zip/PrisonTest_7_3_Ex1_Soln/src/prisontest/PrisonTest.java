package prisontest;

public class PrisonTest {
    public static void main(String[] args) {
        Prisoner p01 = new Prisoner();
        
        System.out.println(p01.name);
        System.out.println(p01.height);
        System.out.println(p01.sentence);
    } 
}
