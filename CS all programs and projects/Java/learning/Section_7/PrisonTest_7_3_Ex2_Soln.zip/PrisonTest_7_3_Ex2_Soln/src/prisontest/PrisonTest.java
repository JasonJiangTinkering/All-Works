package prisontest;

public class PrisonTest {
    public static void main(String[] args) {
        Prisoner p01 = new Prisoner();
        Prisoner p02 = new Prisoner();

        p01.setFields("Bubba", 2.08, 4);
        p02.setFields("Twitch", 1.73, 3);
    } 
}
