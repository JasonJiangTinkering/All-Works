package prisontest;

public class PrisonTest {
    public static void main(String[] args){
        Cell cellA1 = new Cell("A1", false, 1234);
        Prisoner bubba = new Prisoner("Bubba", 2.08, 4, cellA1);
        
        bubba.display();
        cellA1.setIsOpen(1111);
        cellA1.setIsOpen(1234);
        cellA1.setIsOpen(1234);
    }
}
