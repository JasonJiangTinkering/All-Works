
package chickens02;

public class Chickens02 {
    public static void main(String[] args) {
        //Put yout code here

        System.out.println("Daily Average:   " +dailyAverage);
        System.out.println("Monthly Average: " +monthlyAverage);
        System.out.println("Monthly Profit:  $" +monthlyProfit);
    }
    
}
