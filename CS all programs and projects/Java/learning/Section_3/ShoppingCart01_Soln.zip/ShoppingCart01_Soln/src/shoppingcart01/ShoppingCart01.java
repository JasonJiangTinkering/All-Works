
package shoppingcart01;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        
        String custName = "Alex";
        String itemDesc = "Shirt";
        String message = "";        
        
        // Assign the message variable 
        message = custName + " wants to purchase a " + itemDesc;
        
        // Print and run the code
        System.out.println(message);
    }
}
