
package shoppingcart01;

public class ShoppingCart01 {
    public static void main(String[] args) {
        // Declare and initialize String variables.  Do not initialize message yet.
        
        
        
        
        // Assign the message variable 
        
        
        // Print and run the code
        
    }
}
