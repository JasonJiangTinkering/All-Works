
package variables02_example;

public class Variables02_Example {

    public static void main(String[] args) {
        String x = "Sam";
        System.out.println("My name is " +x);
        System.out.println(x +" is so cool!");
        System.out.println("Hooray " +x +"!");
        System.out.println("Please enjoy " +x +" Appreciation "
                + "Day! My name is " +x +". I know how excited "
                + "everyone is to start appreciating " +x +" on " +x
                + " Appreciation Day! " +x +", " +x +", " +x +"! Yay "
                + x +"!!! That's me! " +x +" is the best date ever!");
        
    }
    
}
