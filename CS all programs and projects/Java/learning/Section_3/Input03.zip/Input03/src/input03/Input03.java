package input03;

class Input03 {

    public static void main(String[] args) {
        //Create a Scanner
        
        //Find and print the sum of three integers entered by the user
        
        
        
        
        //Remember to close the Scanner
        
    }
}
