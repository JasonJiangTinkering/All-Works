/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */
public class StringConcatenate {
 
 public static void main(String args[]){  
   String s1="Susan";  
   String s2="Roberts";
   String s=s1+s2;
   System.out.println(s);
  
 }  
} 
    

