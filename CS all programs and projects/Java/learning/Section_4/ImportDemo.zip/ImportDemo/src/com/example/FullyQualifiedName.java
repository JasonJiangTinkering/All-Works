/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */
public class FullyQualifiedName {

    public static void main(String args[]) {
        int num;
        java.util.Scanner keyboard = new java.util.Scanner(System.in);
        System.out.print("Enter a number");
        num = keyboard.nextInt();
        System.out.print("The number you entered is" + num);

    }
}
