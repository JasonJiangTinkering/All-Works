package problemset2_1;

public class ProblemSet2_1 {
    public static void main(String[] args) {
        //Use 8 print statements to print a smiley face.
        //Your art will rely on only a single character, besides space, such as X or #.
        
        
        
        
        
        
        
        
    }   
}
