package problemset2_2;

public class ProblemSet2_2 {
    public static void main(String[] args) {
        //Use print statements to create your own beautiful original ASCII art.
        //Use comments to describe what your image is depicting.
        
        
        
        
        
        
        
        
    } 
}
